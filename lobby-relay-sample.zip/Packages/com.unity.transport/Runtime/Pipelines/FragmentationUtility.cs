
namespace Unity.Networking.Transport.Utilities
{
    public struct FragmentationUtility
    {
        public struct Parameters : INetworkParameter
        {
            public int PayloadCapacity;
        }
    }
}

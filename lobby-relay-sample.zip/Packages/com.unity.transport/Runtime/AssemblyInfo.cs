using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Networking.Transport.EditorTests")]
[assembly: InternalsVisibleTo("Unity.Multiplayer.Transport.UTP")]


namespace Unity.Services.Core.Internal
{
    /// <summary>
    /// Base contract for a functionality defined by the Core package.
    /// </summary>
    public interface IServiceComponent {}
}

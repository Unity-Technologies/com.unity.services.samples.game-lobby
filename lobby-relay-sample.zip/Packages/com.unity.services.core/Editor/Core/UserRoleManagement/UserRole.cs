using System;

namespace Unity.Services.Core.Editor
{
    enum UserRole
    {
        Unknown,
        User,
        Manager,
        Owner
    }
}

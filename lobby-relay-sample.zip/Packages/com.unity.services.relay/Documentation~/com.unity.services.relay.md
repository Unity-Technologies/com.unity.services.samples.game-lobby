# Unity Relay Beta
Welcome to the Relay Beta!
Go to the [Relay Dashboard](https://dashboard.unity3d.com/relay) to learn more, find documentation, and get support.

## SDK Documentation
The SDK is documented using XML comments. These will work with most IDEs to provide IntelliSense and inline documentation.

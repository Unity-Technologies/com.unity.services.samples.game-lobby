# About Authentication SDK

This is the Authentication SDK, a way to manage player accounts through the Unity User Authentication Service (UAS).

This package is currently in pre-release state and is not guaranteed to be fully functional.
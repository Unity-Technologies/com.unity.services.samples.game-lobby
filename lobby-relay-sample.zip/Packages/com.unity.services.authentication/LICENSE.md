com.unity.services.authentication copyright © 2021 Unity Technologies SF

This software is subject to, and made available under, the Unity Operate Terms of Service (see https://unity3d.com/legal/one-operate-services-terms-of-service), and is an "Operate Service" as defined therein.

Unless expressly provided otherwise, the software under this license is made available strictly on an "AS IS" BASIS WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. Please review the terms of service for details on these and other terms and conditions.

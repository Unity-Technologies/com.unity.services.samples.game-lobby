namespace LobbyRelaySample
{
    public class LobbyServiceDataObserver : ObserverBehaviour<LobbyServiceData> { }
}

namespace LobbyRelaySample
{
    public class LocalGameStateObserver : ObserverBehaviour<LocalGameState> { }
}

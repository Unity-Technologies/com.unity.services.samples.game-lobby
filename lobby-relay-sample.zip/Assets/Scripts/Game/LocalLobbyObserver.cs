namespace LobbyRelaySample
{
    public class LocalLobbyObserver : ObserverBehaviour<LocalLobby> { }
}
